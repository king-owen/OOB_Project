from .assignment_demo.models.score import Score
from .assignment_demo.models.score_manager import ScoreManager
